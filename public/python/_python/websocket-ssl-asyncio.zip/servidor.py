#!/usr/bin/python3.6

"""
Servidor
-------------------------------------

./servidor.py 


Servidor http
-------------------------------------

python3.6 -m http.server 8080


Cliente 
-------------------------------------

Observação: como utilizamos um certificado auto-assinado, precisamos dar permissão ao browser de abrir a página. Como o websocket apenas usa SSL, abra uma outra janela no browser, mas na porta 8765:
https://localhost:8765

Siga o procedimento de seu browser para abriar a página. Normalmente você deve clicar em um botão dizendo que quer continuar acessando a página. Se tudo der certo, você receberá a mensagem: Invalid request. Feche a janela e recarrege o cliente em:
http://localhost:8080/cliente.html

"""



import asyncio
import websockets
import time
import shlex
import ssl
import os
import logging
import logging.config


class Servidor:
    def __init__(self):
        self.conectados = []

    @property
    def nconectados(self):
        return len(self.conectados)

    async def conecta(self, websocket, path):
        cliente = Cliente(self, websocket, path)
        if cliente not in self.conectados:
            self.conectados.append(cliente)
            logging.info(f"Novo cliente conectado({websocket.remote_address[0]} {websocket.remote_address[1]}). Total: {self.nconectados}")
        await cliente.gerencia()

    def desconecta(self, cliente):
        if cliente in self.conectados:
            self.conectados.remove(cliente)
        logging.info(f"Cliente {cliente.nome} desconectado. Total: {self.nconectados}")

    async def envia_a_todos(self, origem, mensagem):
        for cliente in self.conectados:
            if origem != cliente and cliente.conectado:
                logging.debug(f"Enviando de <{origem.nome}> para <{cliente.nome}>: {mensagem}")
                await cliente.envia(f"{origem.nome} >> {mensagem}")

    async def envia_a_destinatario(self, origem, mensagem, destinatario):
        for cliente in self.conectados:
            if cliente.nome == destinatario and origem != cliente and cliente.conectado:
                logging.debug(f"Enviando de <{origem.nome}> para <{cliente.nome}>: {mensagem}")
                await cliente.envia(f"PRIVADO de {origem.nome} >> {mensagem}")
                return True
        return False

    def verifica_nome(self, nome):
        for cliente in self.conectados:
            if cliente.nome and cliente.nome == nome:
                return False
        return True


class Cliente:
    def __init__(self, servidor, websocket, path):
        self.cliente = websocket
        self.servidor = servidor
        self.nome = None

    @property
    def conectado(self):
        return self.cliente.open

    async def gerencia(self):
        try:
            await self.envia("Bem vindo ao servidor de chat escrito em Python 3.6 com asyncio e WebSockets."
                             "Identifique-se com /nome SeuNome")
            while True:
                mensagem = await self.recebe()
                if mensagem:
                    logging.info(f"{self.nome} < {mensagem}")
                    await self.processa_comandos(mensagem)
                else:
                    break
        except Exception as e:
            logging.error(f"Erro: {e}", exc_info=e)
        finally:
            self.servidor.desconecta(self)

    async def envia(self, mensagem):
        await self.cliente.send(mensagem)

    async def recebe(self):
        mensagem = await self.cliente.recv()
        return mensagem

    async def processa_comandos(self, mensagem):
        if mensagem.strip().startswith("/"):
            comandos = shlex.split(mensagem.strip()[1:])
            if not len(comandos):
                await self.envia("Comando inválido")
                return
            logging.debug(f"Comandos recebidos: {comandos}")
            comando = comandos[0].lower()
            if comando == "horas":
                await self.envia("Hora atual: " + time.strftime("%H:%M:%S"))
            elif comando == "data":
                await self.envia("Data atual: " + time.strftime("%d/%m/%y"))
            elif comando == "clientes":
                await self.envia(f"{self.servidor.nconectados} clientes conectados")
            elif comando == "nome":
                await self.altera_nome(comandos)
            elif comando == "apenas":
                await self.apenas_para(comandos)
            else:
                await self.envia("Comando desconhecido")
        else:
            if self.nome:  # Verifica se o usuário já definiu seu nome.
                await self.servidor.envia_a_todos(self, mensagem)
            else:
                await self.envia("Identifique-se para enviar mensagens. Use o comando /nome SeuNome")

    async def altera_nome(self, comandos):
        """Altera o nome do usuário corrente, mas verifica se este é único"""
        if len(comandos) > 1 and self.servidor.verifica_nome(comandos[1]):
            self.nome = comandos[1]
            await self.envia(f"Nome alterado com sucesso para {self.nome}")
        else:
            await self.envia("Nome em uso ou inválido. Escolha um outro.")

    async def apenas_para(self, comandos):
        """Envia a mensagem apenas para um cliente específico"""
        if len(comandos) < 3:
            await self.envia("Comando incorreto. /apenas Destinatário mensagem")
            return
        destinatario = comandos[1]
        mensagem = " ".join(comandos[2:])
        enviado = await self.servidor.envia_a_destinatario(self, mensagem, destinatario)
        if not enviado:
            await self.envia(f"Destinatário {destinatario} não encontrado. Mensagem não enviada.")


def server_context():
    """Cria o contexto do SSL, carregando o certificado e a chave gerados"""
    cert = os.path.join(os.path.dirname(__file__), 'cert.pem')
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS)
    ssl_context.load_cert_chain(cert, keyfile="key.pem")
    return ssl_context

LOG_FORMAT = ('%(levelname) -6s %(asctime)s %(name) -20s %(funcName) -25s %(lineno) -5d: %(message)s')



if __name__ == "__main__":
    logging.config.dictConfig(
        {
            'version': 1,
            'formatters': {'verbose': {'format': LOG_FORMAT}},
            'loggers': {'': {'level': 'DEBUG', 'handlers': ['console']},
                        'websockets': {'level': 'INFO', 'handlers': ['console']}},
            'handlers': {
                'console':{
                    'level':'DEBUG',
                    'class':'logging.StreamHandler',
                    'formatter': 'verbose'
                },
            }
        })
    servidor = Servidor()
    loop = asyncio.get_event_loop()

    start_server = websockets.serve(servidor.conecta, '0.0.0.0', 8765, ssl=server_context())

    try:
        loop.run_until_complete(start_server)
        loop.run_forever()
    finally:
        start_server.close()